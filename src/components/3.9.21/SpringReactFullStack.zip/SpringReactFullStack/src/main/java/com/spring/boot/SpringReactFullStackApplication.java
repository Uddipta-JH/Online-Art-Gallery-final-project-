package com.spring.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringReactFullStackApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringReactFullStackApplication.class, args);
	}

}
