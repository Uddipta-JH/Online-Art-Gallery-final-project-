import React from 'react'
import "./LoginHeader.css";
import logopic from "./pngwing.com (4).png";
export const LoginHeader = () => {
    return (
        <div className="sticky-top">
            <nav class="navbar navbar-expand-lg navbar-dark ">
                
                {/* <img src={logopic} alt="..." class="img-thumbnail"/ > */}
                <a class="navbar-brand artgallery" href="#">
                {/* <a className="navbar-brand mt-2 mx-3" href="Home.html"> */}
                  <span style={{ color: "#ff0000" }}>A</span>
                  <span style={{ color: "#ff8700" }}>R</span>
                  <span style={{ color: "#ffd300 " }}>T</span>
                  <span> </span>
                  <span style={{ color: "#deff0a " }}>G</span>
                  <span style={{ color: "#a1ff0a" }}>A</span>
                  <span style={{ color: "#0aff99" }}>L</span>
                  <span style={{ color: "#0aefff" }}>L</span>
                  <span style={{ color: "#147df5" }}>E</span>
                  <span style={{ color: "#580aff " }}>R</span>
                  <span style={{ color: "#be0aff" }}>Y</span>
                </a>
                

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Gallery <span class="sr-only">(current)</span></a>
                    </li>
                    
                    <li class="nav-item dropdown active">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Style
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </li>

                    <li class="nav-item active">
                        <a class="nav-link" href="#">Auction <span class="sr-only">(current)</span></a>
                    </li>

                    <li class="nav-item active">
                        <a class="nav-link" href="#">Blog <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Offers <span class="sr-only">(current)</span></a>
                    </li>
                    </ul>
                    <form class="form-inline my-2 my-lg-0">
                        <a href="">
                        <i class="fas fa-user-circle text-light"/>
                        <b className="text-light ml-2">Rishab Chaudhari</b>
                        </a>
                        <a href="" class="btn btn-outline-light ml-3">Logout</a>
                    </form>
                </div>
            </nav>
        </div>
    )
}
