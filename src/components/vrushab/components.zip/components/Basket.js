import React from 'react';
import { Link } from 'react-router-dom';

export function Basket(){
    return(
        <div className="conatiner-fluid">
    <div className=" container border bg-dark text-white">
        <h1>Cart</h1>
        <h1></h1>
    </div>
    <div className="container border">
        <div className="row">
            <div className="col-10">
                <div className="row">
                    <div className="col-2 my-2">
                    <div className="border border-dark">
                    <img src="https://images.unsplash.com/photo-1612396931345-bb01d8657af3?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80" class="w-100" alt="..." />
                </div>
                    </div>
                    <div className="col-6">
                        <h5 className="text-muted mt-3">Product Name</h5>
                        <p>Price:  2345</p>
                    </div>
                </div>
            </div>
            <div className="col-2 my-auto">
                <Link to="#" className="btn btn-primary">Buy</Link>
                <Link to="#" className="btn btn-primary ml-3">Remove</Link>
            </div>
        </div>
    </div>
    </div> 

    );
}